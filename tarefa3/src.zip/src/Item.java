// Interface base para qualquer item no jogo (armas, poções, etc.

public interface Item {

    // Retorna o nome do item.

    String getNome();
}